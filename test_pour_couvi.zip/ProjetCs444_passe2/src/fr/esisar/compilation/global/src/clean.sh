#!/bin/bash
# Efface les fichiers générés de global/src

rm -f ../../../../../../classes/fr/esisar/compilation/global/src/*.class

echo "global/src : Fichiers générés effacés"

