#!/bin/bash
# Efface les fichiers générés de global/src3

rm -f ../../../../../../classes/fr/esisar/compilation/global/src3/*.class

echo "global/src3 : Fichiers générés effacés"

