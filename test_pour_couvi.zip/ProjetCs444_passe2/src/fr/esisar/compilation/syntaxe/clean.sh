#!/bin/bash
# Efface les fichiers générés de la passe 1

rm -f Lexical.java parser.java sym.java ../../../../../classes/fr/esisar/compilation/syntaxe/*.class

echo "Passe 1 : Fichiers générés effacés"

