package fr.esisar.compilation.syntaxe;

/**
 * Exception levée en cas d'erreur de syntaxe.
 */

public class ErreurSyntaxe extends Exception {

}

