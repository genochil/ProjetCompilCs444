#!/bin/bash
# Efface les fichiers générés de la passe 2

rm -f ../../../../../classes/fr/esisar/compilation/verif/*.class

echo "Passe 2 : Fichiers générés effacés"

