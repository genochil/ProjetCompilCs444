package fr.esisar.compilation.verif;

/**
 * Exception levée en cas d'erreur interne dans ReglesTypage.
 */

public class ErreurReglesTypage extends RuntimeException { }

