#!/bin/bash
# Efface les fichiers générés de la passe 3

rm -f ../../../../../classes/fr/esisar/compilation/gencode/*.class

echo "Passe 3 : Fichiers générés effacés"

