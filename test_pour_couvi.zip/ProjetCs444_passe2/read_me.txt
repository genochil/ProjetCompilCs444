GENOCHIO Loic genochil loic.genochio@etu.esisar.grenoble-inp.fr
CHAMPEY Vincent champeyv vincent.champey@etu.esisar.grenoble-inp.fr
HARTMANN Clémentin hartmanc clementin.hartman@etu.esisar.grenoble-inp.fr
COUVIGNOU Adrien couvigna adrien.couvignou@etu.esisar.grenoble-inp.fr

